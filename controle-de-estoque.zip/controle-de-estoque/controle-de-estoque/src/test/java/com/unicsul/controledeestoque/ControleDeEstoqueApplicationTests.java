package com.unicsul.controledeestoque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleDeEstoqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
