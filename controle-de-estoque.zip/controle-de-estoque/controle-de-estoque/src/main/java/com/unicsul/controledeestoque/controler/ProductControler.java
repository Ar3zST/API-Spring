package com.unicsul.controledeestoque.controler;

import com.unicsul.controledeestoque.model.Product;
import com.unicsul.controledeestoque.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductControler {
    @Autowired
    private ProductRepository productRepository;
    @GetMapping(value = "/produtos")
    public List<Product> getProducts(){
        return productRepository.findAll();
    }
}
