package com.unicsul.controledeestoque.model;
import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
public class Size {
    private double weight;
    private double height;
    private double width;
    private double depth;
}
