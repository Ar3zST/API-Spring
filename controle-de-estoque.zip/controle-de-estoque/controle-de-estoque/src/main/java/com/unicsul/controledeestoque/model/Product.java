package com.unicsul.controledeestoque.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Setter
@Getter
@Document(collection = "produtos")
public class Product {
    private String id;
    private long sku;
    private String name;
    private double price;
    private int qtd;
    private Size size;
    private String img;
}
